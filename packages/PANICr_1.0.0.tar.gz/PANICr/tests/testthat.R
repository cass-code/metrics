library(testthat)
library(PANICr)

test_check("PANICr")
