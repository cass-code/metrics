#' Cointegration test critical values for PANIC (2004) 
#'
#'@name coint0
#'
#'@docType data
#'
#'@description A dataset containing critical values for PANIC (2004) cointegration test
#'
#'
#'
NULL 
