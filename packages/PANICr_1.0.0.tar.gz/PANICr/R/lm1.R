#' KPSS test critical values for PANIC (2004) idiosyncratic test 
#'
#'@name lm1
#'
#'@docType data
#'
#'@description A dataset containing critical values for PANIC (2004) idiosyncratic pooled KPSS test
#'
#'
#'@export
NULL 
