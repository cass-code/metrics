#' ADF critical values for PANIC (2004) demeaned data 
#'
#'@name adfc2
#'
#'@docType data
#'
#'@description A dataset containing critical values for PANIC (2004) demeaned data ADF test
#'
#'@export
#'
NULL 
