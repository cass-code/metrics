#' ADF test critical values for PANIC (2004) idiosyncratic test 
#'
#'@name adfnc
#'
#'@docType data
#'
#'@description A dataset containing critical values for PANIC (2004) idiosyncratic pooled test
#'
#'
#'@export
NULL 
