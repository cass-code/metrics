PANICr
======

PANIC Tests
