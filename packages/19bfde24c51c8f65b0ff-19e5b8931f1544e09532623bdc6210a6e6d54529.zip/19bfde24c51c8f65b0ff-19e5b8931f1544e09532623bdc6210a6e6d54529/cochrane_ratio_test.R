# Released under the MIT License (MIT)
# 
# Copyright (c) 2014 Eric Kemp-Benedict
#   
#   Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#   
#   The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.

# This function was created by the author for a specific analysis.
# It does no checking of inputs.

cochrane.var.ratio <- function(x, max.lag=30) {
  # Computes a series of the variance of 1st difference divided by lag, following
  # Cochrane, J. H. (1988) ‘How Big Is the Random Walk in GNP?’
  #    Journal of Political Economy, 96(5). 893–920.
  # A horizontal trend is consistent with a random walk, while
  # a declining trend is consistent with a stationary series. Many
  # series look like a random walk up to some lag and then shift
  # to a stationary behavior at longer lags. Plotting the ratio
  # of variance of 1st difference divided by lag can be revealing.
  #
  # Note: Methods exist to automatically detect the shift from
  # random walk to stationary behavior. These are used in computational
  # finance, and can be found in the R package vrtest, available on CRAN.
  # For macroeconomic time series, Cochrane's "plot and look" method can be
  # applied in a straightforward manner, and this function generates
  # the appropriate series.
  #
  # Note: this is a simple function and it does not check inputs.
  #
  # Args:
  #   x        : A time series or vector
  #   max.lag  : Maximum number of lags to compute
  #
  # Returns:
  #   Matrix with ratio (column "yr") and the standard error (column "error")
  #
  # Example:
  #   k <- 20
  #   ct <- cochrane.var.ratio(x, max.lag=k)
  #   # Make plot with error bars, similar to plots in Cochrane's paper
  #   plot(1:k,ct[,"vr"],xlab="Lag",ylab="", type="l",
  #     ylim=c(0.0,2.0),
  #     main=expression(paste("Cochrane variance ratio for x")))
  #   lines(1:k,ct[,"vr"] + ct[,"error"],lty=2)
  #   lines(1:k,ct[,"vr"] - ct[,"error"],lty=2)

  y <- matrix(ncol=2,nrow=max.lag)
  colnames(y) <- c("vr","error")
  N <- length(x)
  mu <- mean(diff(x))
  for (k in 1:max.lag) {
    variance <- var(diff(x, lag=k) - mu)
    dof.corr <- N/(N - k + 1)
    # This will become a ratio below
    y[k,"vr"] <- dof.corr * variance/k
    y[k,"error"] <- sqrt(2/(N - k))
  }
  y[,"vr"] <- y[,"vr"]/y[1,"vr"]
  y[,"error"] <- sqrt(y[,"error"]^2 + y[1,"error"]^2)
  return(y)
}

cochrane.plot <- function(x, max.lag=30, varname="x", ylim.ct=NA) {
  # For a given series x, plots the ACF of x and diff(x), the normal quantile
  # plot of diff(x) and the Cochrane variance ratio test, with errors.
  #
  # Note: this function does not check inputs.
  #
  # Args:
  #   x        : A time series or vector
  #   max.lag  : Maximum number of lags to display
  #   varname  : A string name for the variable (expressions won't work)
  #   ylim.ct  : Either "NA" to have them computed automatically or specified ylimits for the
  #              Cochrane variance ratio plot
  #
  # Returns:
  #   Nothing
  #
  # Example:
  #   cochrane.plot(log(GDP), max.lag=20, varname=expression(log(Y)))
  acf.x <- acf(x, lag.max=max.lag, plot=F)
  acf.dx <- acf(diff(x), lag.max=max.lag, plot=F)
  ct <- cochrane.var.ratio(x, max.lag=max.lag)
  
  # Compute ylim if not specified
  if (is.na(ylim.ct)) {
    ct.min <- min(ct[,"vr"] - ct[,"error"])
    ct.max <- max(ct[,"vr"] + ct[,"error"])
    ylim.ct <- c(ct.min, ct.max)
  }
  
  # Save graphics parameters
  mgp.def = par()$mgp
  mfrow.def = par()$mfrow
  cex.axis.def = par()$cex.axis
  cex.main.def = par()$cex.main
  
  par(mgp=c(2,1,0))
  par(mfrow=c(2,2))
  par(cex.axis=0.8, cex.main=1)
  plot(acf.x, main=varname)
  plot(acf.dx, main=bquote(paste(Delta,.(varname))))
  qqnorm(diff(x), main=bquote(paste("Normal Q-Q Plot for", Delta, .(varname))))
  qqline(diff(x))
  plot(1:max.lag,ct[,"vr"],xlab="Lag",ylab="", type="l",
       ylim=ylim.ct,
       main=paste("Cochrane variance ratio for", varname))
  lines(1:max.lag,ct[,"vr"] + ct[,"error"],lty=2)
  lines(1:max.lag,ct[,"vr"] - ct[,"error"],lty=2)
  
  # Restore graphics parameters
  par(mfrow=mfrow.def)
  par(mgp=mgp.def)
  par(cex.axis=cex.axis.def)
  par(cex.main=cex.main.def)
}
